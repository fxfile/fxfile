#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-L/usr/local/lib"
XSLT_LIBS="-lxslt  -L/usr/local/lib -lxml2 -L/usr/local/lib -lz -L/usr/local/lib -liconv -lws2_32  "
XSLT_INCLUDEDIR="-I/usr/local/include"
MODULE_VERSION="xslt-1.1.28"
